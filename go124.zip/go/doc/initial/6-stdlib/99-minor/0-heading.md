### Minor changes to the library {#minor_library_changes}


